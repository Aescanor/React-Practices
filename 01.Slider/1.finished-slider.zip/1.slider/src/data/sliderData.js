 const sliderData = [
  {
    id: 1,
    description: "Leaving room"
  },
  {
    id: 2,
    description: "Kitchen"
  },
  {
    id: 3,
    description: "Bedroom"
  },
  {
    id: 4,
    description: "Bathroom"
  },
  {
    id: 5,
    description: "Balcony"
  },
]
export default sliderData;