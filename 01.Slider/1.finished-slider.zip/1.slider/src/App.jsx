import Slider from "./components/Slider/Slider"

function App() {
  return <Slider />
}

export default App
